// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xturbovla_lite_e2e.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XTurbovla_lite_e2e_CfgInitialize(XTurbovla_lite_e2e *InstancePtr, XTurbovla_lite_e2e_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XTurbovla_lite_e2e_Start(XTurbovla_lite_e2e *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL) & 0x80;
    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XTurbovla_lite_e2e_IsDone(XTurbovla_lite_e2e *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XTurbovla_lite_e2e_IsIdle(XTurbovla_lite_e2e *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XTurbovla_lite_e2e_IsReady(XTurbovla_lite_e2e *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XTurbovla_lite_e2e_EnableAutoRestart(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XTurbovla_lite_e2e_DisableAutoRestart(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XTurbovla_lite_e2e_Get_return(XTurbovla_lite_e2e *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XTurbovla_lite_e2e_Set_arena(XTurbovla_lite_e2e *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ARENA_DATA, (u32)(Data));
    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ARENA_DATA + 4, (u32)(Data >> 32));
}

u64 XTurbovla_lite_e2e_Get_arena(XTurbovla_lite_e2e *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ARENA_DATA);
    Data += (u64)XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ARENA_DATA + 4) << 32;
    return Data;
}

void XTurbovla_lite_e2e_InterruptGlobalEnable(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_GIE, 1);
}

void XTurbovla_lite_e2e_InterruptGlobalDisable(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_GIE, 0);
}

void XTurbovla_lite_e2e_InterruptEnable(XTurbovla_lite_e2e *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_IER);
    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_IER, Register | Mask);
}

void XTurbovla_lite_e2e_InterruptDisable(XTurbovla_lite_e2e *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_IER);
    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_IER, Register & (~Mask));
}

void XTurbovla_lite_e2e_InterruptClear(XTurbovla_lite_e2e *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTurbovla_lite_e2e_WriteReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ISR, Mask);
}

u32 XTurbovla_lite_e2e_InterruptGetEnabled(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_IER);
}

u32 XTurbovla_lite_e2e_InterruptGetStatus(XTurbovla_lite_e2e *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTurbovla_lite_e2e_ReadReg(InstancePtr->Control_BaseAddress, XTURBOVLA_LITE_E2E_CONTROL_ADDR_ISR);
}

