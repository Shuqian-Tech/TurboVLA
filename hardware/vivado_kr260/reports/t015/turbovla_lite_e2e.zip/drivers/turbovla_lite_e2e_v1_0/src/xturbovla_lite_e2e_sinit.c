// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xturbovla_lite_e2e.h"

extern XTurbovla_lite_e2e_Config XTurbovla_lite_e2e_ConfigTable[];

#ifdef SDT
XTurbovla_lite_e2e_Config *XTurbovla_lite_e2e_LookupConfig(UINTPTR BaseAddress) {
	XTurbovla_lite_e2e_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XTurbovla_lite_e2e_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XTurbovla_lite_e2e_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XTurbovla_lite_e2e_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XTurbovla_lite_e2e_Initialize(XTurbovla_lite_e2e *InstancePtr, UINTPTR BaseAddress) {
	XTurbovla_lite_e2e_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XTurbovla_lite_e2e_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XTurbovla_lite_e2e_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XTurbovla_lite_e2e_Config *XTurbovla_lite_e2e_LookupConfig(u16 DeviceId) {
	XTurbovla_lite_e2e_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XTURBOVLA_LITE_E2E_NUM_INSTANCES; Index++) {
		if (XTurbovla_lite_e2e_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XTurbovla_lite_e2e_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XTurbovla_lite_e2e_Initialize(XTurbovla_lite_e2e *InstancePtr, u16 DeviceId) {
	XTurbovla_lite_e2e_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XTurbovla_lite_e2e_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XTurbovla_lite_e2e_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

