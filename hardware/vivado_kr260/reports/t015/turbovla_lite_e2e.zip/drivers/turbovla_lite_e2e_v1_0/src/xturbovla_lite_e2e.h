// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XTURBOVLA_LITE_E2E_H
#define XTURBOVLA_LITE_E2E_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xturbovla_lite_e2e_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XTurbovla_lite_e2e_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XTurbovla_lite_e2e;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XTurbovla_lite_e2e_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XTurbovla_lite_e2e_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XTurbovla_lite_e2e_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XTurbovla_lite_e2e_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XTurbovla_lite_e2e_Initialize(XTurbovla_lite_e2e *InstancePtr, UINTPTR BaseAddress);
XTurbovla_lite_e2e_Config* XTurbovla_lite_e2e_LookupConfig(UINTPTR BaseAddress);
#else
int XTurbovla_lite_e2e_Initialize(XTurbovla_lite_e2e *InstancePtr, u16 DeviceId);
XTurbovla_lite_e2e_Config* XTurbovla_lite_e2e_LookupConfig(u16 DeviceId);
#endif
int XTurbovla_lite_e2e_CfgInitialize(XTurbovla_lite_e2e *InstancePtr, XTurbovla_lite_e2e_Config *ConfigPtr);
#else
int XTurbovla_lite_e2e_Initialize(XTurbovla_lite_e2e *InstancePtr, const char* InstanceName);
int XTurbovla_lite_e2e_Release(XTurbovla_lite_e2e *InstancePtr);
#endif

void XTurbovla_lite_e2e_Start(XTurbovla_lite_e2e *InstancePtr);
u32 XTurbovla_lite_e2e_IsDone(XTurbovla_lite_e2e *InstancePtr);
u32 XTurbovla_lite_e2e_IsIdle(XTurbovla_lite_e2e *InstancePtr);
u32 XTurbovla_lite_e2e_IsReady(XTurbovla_lite_e2e *InstancePtr);
void XTurbovla_lite_e2e_EnableAutoRestart(XTurbovla_lite_e2e *InstancePtr);
void XTurbovla_lite_e2e_DisableAutoRestart(XTurbovla_lite_e2e *InstancePtr);
u32 XTurbovla_lite_e2e_Get_return(XTurbovla_lite_e2e *InstancePtr);

void XTurbovla_lite_e2e_Set_arena(XTurbovla_lite_e2e *InstancePtr, u64 Data);
u64 XTurbovla_lite_e2e_Get_arena(XTurbovla_lite_e2e *InstancePtr);

void XTurbovla_lite_e2e_InterruptGlobalEnable(XTurbovla_lite_e2e *InstancePtr);
void XTurbovla_lite_e2e_InterruptGlobalDisable(XTurbovla_lite_e2e *InstancePtr);
void XTurbovla_lite_e2e_InterruptEnable(XTurbovla_lite_e2e *InstancePtr, u32 Mask);
void XTurbovla_lite_e2e_InterruptDisable(XTurbovla_lite_e2e *InstancePtr, u32 Mask);
void XTurbovla_lite_e2e_InterruptClear(XTurbovla_lite_e2e *InstancePtr, u32 Mask);
u32 XTurbovla_lite_e2e_InterruptGetEnabled(XTurbovla_lite_e2e *InstancePtr);
u32 XTurbovla_lite_e2e_InterruptGetStatus(XTurbovla_lite_e2e *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
